#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>


void save (personnage p,int valeur_score,vie v,temps t,int etat,int nb_potion);
void load (personnage *p,int valeur_score,vie v,temps t,int etat,int nb_potion);

